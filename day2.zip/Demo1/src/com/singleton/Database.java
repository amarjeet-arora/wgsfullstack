package com.singleton;

public class Database {
	private static Database singleObj;
	private int record;
	private String name;
	 
	 
	public int getRecord() {
		return record;
	}
	public void setRecord(int record) {
		this.record = record;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private Database(String n) {
		 name=n;
		 record=0;
	}
	public static Database getInstance(String n) {
		if(singleObj == null) {
			System.out.println("new object in process");
			singleObj= new Database(n);
		}
		System.out.println("existing");
		return singleObj;
	}

}
