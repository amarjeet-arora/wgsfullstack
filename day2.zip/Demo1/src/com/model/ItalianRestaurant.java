package com.model;

public class ItalianRestaurant implements Restaurant{

	@Override
	public String prepareDish(String dishName) {
		 
		return "Preparing " + dishName + " with italian Herbs";
	}

}
