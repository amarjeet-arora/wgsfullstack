package facade;

import java.util.LinkedList;
import java.util.List;

public class RoomSearchService {
	
	private List<Room> rooms;
	
	public RoomSearchService() {
		rooms= new LinkedList<Room>();
	}
public void addRoom(Room room) {
	rooms.add(room);
}
public List<Room> search(RoomType roomType){
	List<Room> searchList= new LinkedList<Room>();
	for(Room r: rooms) {
		if(r.isVacant() && r.getRoomType().equals(roomType))
			searchList.add(r);
		
	}
	return searchList;
}

public void reserveRoom(int rNo) {
	for(Room r :rooms) {
		if(r.getRno()==rNo) {
			r.setVacant(false);
			return;
		}
	}
		
}




}
