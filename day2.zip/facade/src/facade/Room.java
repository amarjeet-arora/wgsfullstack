package facade;

public class Room {
	
	private int rno;
	private RoomType roomType;
	private boolean vacant;
	public Room() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Room(int rno, RoomType roomType, boolean vacant) {
		super();
		this.rno = rno;
		this.roomType = roomType;
		this.vacant = vacant;
	}
	@Override
	public String toString() {
		return "Room [rno=" + rno + ", roomType=" + roomType + ", vacant=" + vacant + "]";
	}
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public RoomType getRoomType() {
		return roomType;
	}
	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}
	public boolean isVacant() {
		return vacant;
	}
	public void setVacant(boolean vacant) {
		this.vacant = vacant;
	}

}
