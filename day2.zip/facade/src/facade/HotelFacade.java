package facade;

import java.util.List;

public class HotelFacade {

	RoomSearchService roomSearchService;
	HotelFacade(){
		roomSearchService= new RoomSearchService();
		for(int i=0;i<20;i++) {
			if(i%2==0) 
				roomSearchService.addRoom(new Room(i+1, RoomType.SINGLE, true));
				else  
					roomSearchService.addRoom(new Room(i+1, RoomType.DOUBLE, true));
				
		}
		}
		public String reserve(RoomType rt) {
			List<Room> rooms= roomSearchService.search(rt);
			if(rooms.size() >0) {
				roomSearchService.reserveRoom(rooms.get(0).getRno());
				return "success";
			}
			else 
				return "failure";
		
	}
		public void displayAvailableRooms() {
			System.out.println(roomSearchService.search(RoomType.SINGLE));
			System.out.println(roomSearchService.search(RoomType.DOUBLE));

		}
}
