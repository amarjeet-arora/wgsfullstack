package facade;

public class FrontDesk {
public static void main(String[] args) {
	HotelFacade facade= new HotelFacade();
	
	facade.displayAvailableRooms();
	
	System.out.println(facade.reserve(RoomType.SINGLE));
	System.out.println(facade.reserve(RoomType.DOUBLE));
	facade.displayAvailableRooms();


}
}
