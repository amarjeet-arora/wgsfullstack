package facade;

public enum RoomType {
	
	SINGLE ,DOUBLE;

}
