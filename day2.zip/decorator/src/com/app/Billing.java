package com.app;

public class Billing {

	public static void main(String[] args) {
		 
		Sale sale= new Sale(15, 2000);
		sale=new DiscountDecorator(sale);
		sale= new BatchDecorator(sale);

		System.out.println(sale.getTotal());
	}

}
