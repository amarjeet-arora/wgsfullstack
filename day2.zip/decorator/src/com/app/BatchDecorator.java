package com.app;

public class BatchDecorator  extends SaleDecorator{

	Sale sale;
	@Override
	public double getTotal() {
	
if(sale.getNop() >10 )
	return sale.getTotal()-10;
		return sale.getTotal(); 
	}

	public BatchDecorator(Sale sale) {
		super();
		this.sale = sale;
	}

	public int getNop() {
		return sale.getNop();
	}
}
