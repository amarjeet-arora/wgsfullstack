package com.app;

public class DiscountDecorator extends SaleDecorator {

	Sale sale;
	
	public DiscountDecorator(Sale sale) {
		super();
		this.sale = sale;
	}

	@Override
	public double getTotal() {
		// TODO Auto-generated method stub
		return sale.getTotal()-(5.0/100.0*sale.getTotal());
	}
	public int getNop() {
		return sale.getNop();
	}

}
