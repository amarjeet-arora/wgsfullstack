package com.oldcomponent;

public interface AceInterface {
public void setName(String name);
public String getName();
}
