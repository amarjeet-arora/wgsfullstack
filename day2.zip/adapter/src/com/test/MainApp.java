package com.test;

import com.adapter.AceToAcme;
import com.oldcomponent.AceClass;

public class MainApp {

	public static void main(String[] args) {
		 AceClass aceClass= new AceClass();
		 aceClass.setName("Amarjeet Singh");
		 AceToAcme aceToAcme= new AceToAcme(aceClass);
		 System.out.println(aceToAcme.getFirstName());
		 System.out.println(aceToAcme.getLastName());


	}

}
