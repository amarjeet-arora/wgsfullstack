package com.adapter;

import com.newcomponent.AcmeInterface;
import com.oldcomponent.AceClass;

public class AceToAcme implements AcmeInterface{
	public String firstName;
	public String lastName;
	AceClass aceClass;

	public AceToAcme(AceClass aceClass) {
		 
		this.aceClass = aceClass;
		firstName=aceClass.getName().split(" ")[0];
		lastName=aceClass.getName().split(" ")[1];
	}

	@Override
	public void setFirstName(String firstName) {
		this.firstName=firstName;
		
	}

	@Override
	public void setLastName(String lastName) {
		 this.lastName=lastName;
		
	}

	@Override
	public String getFirstName() {
		 
		return firstName;
	}

	@Override
	public String getLastName() {
		 
		return lastName;
	}
	
}
