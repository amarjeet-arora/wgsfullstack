package com.newcomponent;

public interface AcmeInterface {
	
	public void setFirstName(String fName);
	public void setLastName(String lName);
	public String getFirstName();
	public String getLastName();

}
