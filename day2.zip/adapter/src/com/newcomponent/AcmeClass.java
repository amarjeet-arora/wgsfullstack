package com.newcomponent;

public class AcmeClass  implements AcmeInterface{

	public String firstName;
	public String lastName;
	@Override
	public void setFirstName(String firstName) {
		this.firstName=firstName;
		
	}
	@Override
	public void setLastName(String lastName) {
		this.lastName=lastName;
		
	}
	@Override
	public String getFirstName() {
	 
		return firstName;
	}
	@Override
	public String getLastName() {
		 
		return lastName;
	}
	
}
