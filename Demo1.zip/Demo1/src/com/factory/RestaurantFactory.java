package com.factory;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.model.IndianRestaurant;
import com.model.ItalianRestaurant;
import com.model.Restaurant;
 
public class RestaurantFactory {

	

	 private static Map<String, Restaurant> maps;
	static {
		maps= new HashMap<String, Restaurant>();
		maps.put("I", new IndianRestaurant());
		maps.put("T", new ItalianRestaurant());
	}

	public static Restaurant create(String type) {
		 System.out.println(maps.get(type));
		return maps.get(type);
	}
	private RestaurantFactory() {
		
	}
}
