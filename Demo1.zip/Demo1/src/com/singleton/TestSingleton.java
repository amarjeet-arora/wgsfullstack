package com.singleton;

public class TestSingleton {
	public static void main(String[] args) {
		Database database;
		database=Database.getInstance("Products");
		System.out.println("This is is  "+ database.getName() + " database");
		database=Database.getInstance("employees");
		System.out.println("This is is  "+ database.getName() + " employees");
	}

}
