package com.client;

import com.factory.RestaurantFactory;
import com.model.IndianRestaurant;
import com.model.ItalianRestaurant;
import com.service.RoomService;

public class RoomGuest {

	public static void main(String[] args) {
		 
		RoomService rs= new RoomService(RestaurantFactory.create("I"));
		 
		
		System.out.println(rs.placeOrder("Dosa"));
		 

	}

}
