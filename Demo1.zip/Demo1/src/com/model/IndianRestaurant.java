package com.model;

public class IndianRestaurant implements Restaurant{

	@Override
	public String prepareDish(String dishName) {
		 
		return "Preparing " + dishName + " with indian spices";
	}

}
